/* ***** BEGIN LICENSE BLOCK *****
 *
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: YSlow 2
 *
 * The Initial Developer of the Original Code is Yahoo! Inc.
 *
 * Copyright (C) 2009, Yahoo! Inc. All Rights Reserved.
 *
 * Contributor(s):
 *     Antonia Kwok
 *
 * ***** END LICENSE BLOCK ***** */


//Create the Lints namespace within the global YSLOW namespace.
if ( typeof YSLOW.JSLint == "undefined") {
    YSLOW.JSLint = {};
}

YSLOW.JSLint = {

    jslintcntr: 0,

    runJSLint: function(doc, cset) {
        var lintResult = this.loadJSLint(doc, cset);

	var sErrCount = "<div class=bailed>" + ( 0 === YSLOW.JSLINT.errors.length || YSLOW.JSLINT.errors[YSLOW.JSLINT.errors.length-1] ? YSLOW.JSLINT.errors.length : YSLOW.JSLINT.errors.length-1 ) + " problems found.</div>\n";
	var sBailed = "";
        var sErrors = "";

        if (lintResult) {
            if ( lintResult.lastErrObj && lintResult.lastErrObj.reason.match(/Too many errors. \(([0-9]*)% scanned/) ) {
	        // JSLint bailed early because of too many errors. Make it clear to the user.
	        sBailed = "<div class=bailed>JSLint stopped after analyzing " + RegExp.$1 + "% of the code because there were too many errors.</div>\n";
	    }

            for (var i = 0; i < lintResult.results.length; i++) {
                var result = lintResult.results[i];
                var exp_col_id = "jslintdiv_" + result.id;    // iError is unique across all divs
	        var hrefScript = 'target="_blank" href="' + result.script + '"';
	        if ( -1 != result.script.indexOf("script tag") ) {
	            sErrors += '<div class=scriptheader>' +
		        '<a href="javascript:exp_col(\'' + exp_col_id + '\')"><img id="' + exp_col_id + '_img" border=0 src="http://us.i1.yimg.com/us.yimg.com/i/us/plus/csp/cn/norgie_open_dna.gif"></a> ' +
		        '<b>' + result.script + '</b></div><div class=exp_col_div id=' + exp_col_id + '>';
	        }
	        else {
	            sErrors += '<div class=scriptheader>' +
		        '<a href="javascript:exp_col(\'' + exp_col_id + '\')"><img id="' + exp_col_id + '_img" border=0 src="http://us.i1.yimg.com/us.yimg.com/i/us/plus/csp/cn/norgie_open_dna.gif"></a> ' +
		        '<a ' + hrefScript + '><b>' + result.script + '</b></a></div><div class=exp_col_div id=' + exp_col_id + '>';
                }
                for (var j = 0; j < result.errors.length; j++) {
                    var error = result.errors[j];
                    var sClassname = "errclass";
	            var iDelta = 20;
                    var iChar = error.character;
	            var i1 = ( iChar - iDelta >= 0 ? iChar - iDelta : 0 );
	            var i2 = iChar + iDelta;
                    var sLine = error.code;
	            // Find a better breaking point - semi-colon?
	            if ( i1 < 30 ) {
	                i1 = 0;  // start at the beginning if we're already close to there
	            }
	            if ( 0 !== i1 && -1 !== sLine.lastIndexOf(';', i1) ) {
	                i1 = sLine.lastIndexOf(';', i1) + 1;
	            }
	            if ( i2 > sLine.length-30 ) {
	                i2 = sLine.length-1;
	            }
	            if ( i2 < sLine.length-1 && -1 !== sLine.indexOf(';', i2) ) {
	                i2 = sLine.indexOf(';', i2) + 1;
	            }
	            if ( iChar >= i2 ) {
	                i2 = iChar+1;
	            }

	            sErrors += "<div class='" + sClassname + "," + ( 0 === YSLOW.util.mod(result.id, 2) ? "jserrorEven" : "jserrorOdd" ) + "'>";
	            sErrors += YSLOW.util.escapeHtml(error.reason) + " line " + error.line + ", char " + iChar +
                        ":&nbsp;&nbsp;&nbsp;" + "<a href='javascript:ignoreError(\"" + sClassname +
                        "\")' class=eplink style='font-size: 0.8em;'>ignore all</a>";

	            sErrors += "<div style='margin-left: 30px;'><nobr><code>" + ( 0 === i1 ? "" : "..." ) +
                        YSLOW.util.escapeHtml(sLine.substring( i1, iChar )) +
	                "<span style='background: #FBB'>" + sLine.substring( iChar, iChar+1 ) + "</span>" +
	                YSLOW.util.escapeHtml(sLine.substring(iChar+1, i2)) +
	                ( i2 >= sLine.length-1 ? "" : "..." ) + "</code>" + "</nobr></div></div>\n";
                }
                sErrors += "</div>";
            }
        }

        var sHtml = '<div class=titleheader><font style="font-size: 2em;">JSLint Report for: </font>' +
            YSLOW.util.escapeHtml(doc.location.href) +
            '</div>\n' +
            sErrCount +
            sBailed +
            '<p style="margin-top: 8px;">\n' +
            sErrors +
            '<p style="margin-top: 15px;"><hr><a href="http://jslint.com/">JSLint</a>' +
            'is courtesy of <a href="mailto:douglas@crockford.com">Douglas Crockford</a>. Copyright 2002. '+
            '<a href="http://www.crockford.com/">All Rights Reserved Wrrrldwide</a>.' +
            '';
        var doctitle = 'JSLint Report for: ' + YSLOW.util.escapeHtml(doc.location.href.substring(0, 25));

        var URI = 'chrome://yslow/content/yslow/tool.css';
        var req = new XMLHttpRequest();
        req.open('GET', URI, false);
        req.send(null);
        var css = req.responseText;

        var js ='function ignoreError(sClass) {\n' +
            '   var aDivs = document.getElementsByTagName("div");\n' +
            '   for ( var i = 0; i < aDivs.length; i++ ) {\n' +
            '       if ( -1 != aDivs[i].className.indexOf(sClass) ) {\n' +
            '           aDivs[i].style.display = "none";\n' +
            '       }\n' +
            '   }\n' +
            '}\n' +
            'function exp_col(id, bExpand) {\n' +
            '   var element = document.getElementById(id);\n' +
            '   var image = document.getElementById(id + "_img");\n' +
            '   if ( element && image ) {\n' +
            '       if ( "undefined" == typeof(bExpand) ) {\n' +
            '           bExpand = ( -1 == image.src.indexOf("open") );\n' +
            '       }\n' +
            '       element.style.display = ( bExpand ? "block" : "none" );\n' +
            '       image.src = "http://us.i1.yimg.com/us.yimg.com/i/us/plus/csp/cn/norgie_" + ( bExpand ? "open" : "closed" ) + "_dna.gif";\n' +
            '   }\n' +
            '}';

        sHtml = '<!--<h1>' + doctitle + '</h1>-->' + sHtml;
        return {'css': css, 'js': js, 'html': sHtml};
    },

    loadJSLint: function(doc, components, jslintOptions) {
        YSLOW.JSLint.jslintcntr = 0;
        return YSLOW.JSLint.launchJSLint(doc, components, jslintOptions);
    },

    // Complications:
    // - We need to submit ALL the JS code in one call to JSLINT. Otherwise, JSLINT
    //   complains about undefined symbols that are from other external js files.
    launchJSLint: function(doc, components, jslintOptions) {
        if (typeof YSLOW.JSLINT !== "function") {
            YSLOW.JSLint.jslintcntr++;
            if (YSLOW.JSLint.jslintcntr > 5) {
                YSLOW.util.dump("YSLOW.JSLint.launchJSLint: Failed to load fulljslint.js!  continuing anyway");
            } else {
                YSLOW.platform.util.setTimer(function() { YSLOW.JSLint.launchJSLint(doc, components); }, 1000);
                return {};
            }
        }

        if (jslintOptions === undefined || jslintOptions === null) {
            jslintOptions =  { 'browser' : true, 'undef' : true };
        }

	// If we got here, the jslint file is loaded.
	var aJSCode = [];
	var sJSCode = "";
	var aScriptsInfo = [];
	var nLineTotal = 0;
        var i;

	// Iterate over the external JS files.
	var aComponents = components.getComponentsByType('js');
	for ( i = 0; i < aComponents.length; i++ ) {
	    var compObj = aComponents[i];
	    if ( typeof compObj.body === "string" && compObj.body.length > 0 ) {
		sJSCode += compObj.body;
		aJSCode = aJSCode.concat(compObj.body.split("\n"));
		aScriptsInfo.push( { url: compObj.url, lines: (aJSCode.length-nLineTotal) } );
		nLineTotal = aJSCode.length;
	    }
	}

	// Iterate over the inline SCRIPT blocks.
	var aScripts = doc.getElementsByTagName("script");
	var bFirstInline = true;
	var iScripts = 0;
	for ( i = 0; i < aScripts.length; i++ ) {
	    var script = aScripts[i];
	    if ( !script.src ) {  // avoid external script objects
	        iScripts++;
		sJSCode += script.innerHTML;
		aJSCode = aJSCode.concat(script.innerHTML.split("\n"));
		aScriptsInfo.push( { 'url': "script tag #" + iScripts, 'lines': (aJSCode.length-nLineTotal) } );
		nLineTotal = aJSCode.length;
	    }
	}

        var jslintContext = { jslintUrl: "", results: [] };

        if (aScriptsInfo.length == 0) {
            return jslintContext;
        }

	var lastErrObj;  // So we can track if JSLint bailed early.
	if ( ! YSLOW.JSLINT(aJSCode, jslintOptions) ) {
            jslintContext.jslintUrl = "";  // keep track of the current script URL we're evaluating
	    var hClasses = {};
	    var nClasses = 0;
	    for ( i = 0; i < YSLOW.JSLINT.errors.length; i++ ) {
		var errObj = YSLOW.JSLINT.errors[i];
		if ( errObj ) {         // the last errObj can be NULL
		    lastErrObj = errObj;
		    var sReason = YSLOW.JSLint.cleanReason(errObj.reason);
		    if ( ! hClasses[ sReason ] ) {
			// Give each error type a unique #.
                        // We use this to generate a css classname for hiding errors by type.
			nClasses++;
			hClasses[ sReason ] = nClasses;
		    }
                    YSLOW.JSLint.genError(jslintContext, errObj, aScriptsInfo, aJSCode, "errclass" + hClasses[sReason], i);
		}
	    }
	}

        jslintContext.lastErrObj = lastErrObj;
        return jslintContext;
    },

    // Extract a substring from the line of JS code that includes the error location.
    // Also close/open new div when the JS source (external file or inline) changes.
    genError: function(jslintContext, errObj, aScriptsInfo, aJSCode, sClassname, iError) {

	var nLineTotal = 0;
	var iRelLine = 0;
	var sScript = "";
	var iLine = parseInt(errObj.line, 10);   // this is relative to all the js combined together and is ZERO BASED!!
	var iChar = parseInt(errObj.character, 10);   // this is relative to all the js combined together
	for ( var i = 0; i < aScriptsInfo.length; i++ ) {
	    if ( iLine < (nLineTotal + aScriptsInfo[i].lines) ) {
		iRelLine = iLine - nLineTotal + 1;  // because it's zero-based
		sScript = aScriptsInfo[i].url;
		break;
	    }
	    nLineTotal += aScriptsInfo[i].lines;
        }

	if ( sScript != jslintContext.jslintUrl ) {
	    jslintContext.jslintUrl = sScript;
            jslintContext.results.push( { "script": sScript, "id": iError, "errors": []} );
	}

        var jslintErrorEntry = {};
        jslintErrorEntry.reason = errObj.reason;
        jslintErrorEntry.line = iRelLine;
        jslintErrorEntry.character = iChar;
        jslintErrorEntry.evidence = errObj.evidence;
        jslintErrorEntry.raw = errObj.raw;
        jslintErrorEntry.code = aJSCode[iLine];

        jslintContext.results[jslintContext.results.length-1].errors.push(jslintErrorEntry);

    },


    // Some reasons are different, but are really the same.
    // Normalize them here.
    cleanReason: function(sReason) {
	if ( -1 != sReason.indexOf("Missing '{' before") ) {
	    sReason = "Missing '{' before";
	}
        return sReason;
    }


};


