pref('extensions.Activity.collect_complete_call_graphs', false);

pref('extensions.Activity.ui_resolution_msec', 20);
pref('extensions.Activity.ui_max_displayable_resolutions', 1000);
pref('extensions.Activity.ui_refresh_delay_msec', 150);
pref('extensions.Activity.ui_data_available_instantaneous', true);

pref('extensions.Activity.profile_js', true);
pref('extensions.Activity.canvas_width_px', 250);
pref('extensions.Activity.enable_screen_snapshots', false);
