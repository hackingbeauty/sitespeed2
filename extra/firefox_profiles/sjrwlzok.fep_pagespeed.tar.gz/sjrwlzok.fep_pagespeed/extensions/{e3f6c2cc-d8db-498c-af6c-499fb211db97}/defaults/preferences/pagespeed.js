pref('extensions.PageSpeed.autorun', false);
pref('extensions.PageSpeed.autorun.delay', 100);
pref('extensions.PageSpeed.js_coverage.enable', false);
pref('extensions.PageSpeed.js_coverage.max_functions_per_script', 100);
pref('extensions.PageSpeed.js_coverage.track_function_size', false);
pref('extensions.PageSpeed.enable_console_logging', false);
pref('extensions.PageSpeed.show_all_user_agents', false);
pref('extensions.PageSpeed.beacon.minimal.url', 
     'http://www.showslow.com/beacon/pagespeed/');
pref('extensions.PageSpeed.beacon.minimal.enabled', true);
pref('extensions.PageSpeed.beacon.full_results.url', '');
pref('extensions.PageSpeed.beacon.full_results.enabled', true);
